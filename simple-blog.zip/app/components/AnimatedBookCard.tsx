'use client'

import React, { useRef, useEffect } from 'react'
import Link from 'next/link'
import Image from 'next/image'
import { gsap } from 'gsap'
import { ScrollTrigger } from 'gsap/ScrollTrigger'

interface AnimatedBookCardProps {
  slug: string
  title: string
  author: string
  description: string
  genre: string
  image: string
}

const AnimatedBookCard: React.FC<AnimatedBookCardProps> = ({ slug, title, author, description, genre, image }) => {
  const cardRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    gsap.registerPlugin(ScrollTrigger)

    gsap.fromTo(
      cardRef.current,
      {
        opacity: 0,
        y: 100,
        rotateX: 45,
      },
      {
        opacity: 1,
        y: 0,
        rotateX: 0,
        duration: 1,
        ease: 'power3.out',
        scrollTrigger: {
          trigger: cardRef.current,
          start: 'top bottom-=100',
          end: 'bottom center',
          toggleActions: 'play none none reverse',
        },
      }
    )
  }, [])

  return (
    <Link href={`/books/${slug}`}>
      <div
        ref={cardRef}
        className="border rounded-lg overflow-hidden shadow-md hover:shadow-lg transition-shadow bg-rosePine-surface dark:bg-rosePineMoon-surface"
      >
        <Image
          src={image}
          alt={title}
          width={600}
          height={400}
          className="object-cover w-full h-48"
        />
        <div className="p-4">
          <h2 className="text-xl font-semibold mb-2 text-rosePine-text dark:text-rosePineMoon-text">{title}</h2>
          <p className="text-sm text-rosePine-subtle dark:text-rosePineMoon-subtle mb-2">by {author}</p>
          <p className="text-sm text-rosePine-text dark:text-rosePineMoon-text mb-2">{description}</p>
          <span className="text-sm text-rosePine-foam dark:text-rosePineMoon-foam">{genre}</span>
        </div>
      </div>
    </Link>
  )
}

export default AnimatedBookCard

